<?php

/* 
 * Copyright (C) 2015 milstrike
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
//include "my-conf.php";

$error='';
$i = 0;

$namaTabel = $_SESSION['ikip_pegawai'];

$jumlahData = $_SESSION["jumlah_data"];
if (isset($_POST['check'])) {
    while($i <= $jumlahData){
    if (empty($_POST['ci'."$i"]) || empty($_POST['tkia'."$i"]) || empty($_POST['bobot'."$i"])) {
            
        }
        else
        {
            $ci = $_POST['ci'."$i"];
            $tkia = $_POST['tkia'."$i"];
            $tkib = $_POST['tkib'."$i"];
            $nkk = $ci/$tkia;
            $bobot = $_POST['bobot'."$i"];
            $sum = $nkk * $bobot;
    }   
    }
}


